
package valami;



public enum FieldValue {
    WHITEHORSE,  BLACKHORSE, WHITE, BLACK, GREEN, EMPTY
}