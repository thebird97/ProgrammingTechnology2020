package valami;

import java.awt.*;

import java.awt.event.*;
import javax.swing.*;
public class JButtonTextChangeTest  extends JFrame {
   private JTextField textField;
    private JLabel label;
    public int size = 8;
      public final JButton[][] grid = new JButton[size][size];
       public Model model;
  
  int    isWhite = 0;
       public JButtonTextChangeTest() {
        this.size = 8;
     model = new Model(size);
       
        setTitle("Sudoku");
        setSize(400, 450);
     
       //        java.net.URL    url = JButtonTextChangeTest.class.getResource("smallhorse.png");
       //  setIconImage(Toolkit.getDefaultToolkit().getImage(url));
       //JButton button = new JButton(new ImageIcon("C:water.bmp");
       // button1 = new JButton();
       //button2 = new JButton();
       //      button3 = new JButton();
       // button1.setIcon(new ImageIcon(getClass().getResource("smallwhite.png")));
       // button2.setBackground(Color.GRAY);
       //  button3.setBackground(Color.GRAY);
       /*     button1.addActionListener(new ActionListener() {
       public void actionPerformed(ActionEvent ae) {
       //button.setText(textField.getText());
     //button1.setIcon(new ImageIcon(getClass().getResource("smallbalck.png")));,
       //button1.setColor(255);
       //    button1.setIcon(null);
       //   button1.setBackground(Color.WHITE);
       //  button2.setBackground(Color.WHITE);
       //   button2.setIcon(new ImageIcon(getClass().getResource("smallwhite.png")));
       }
       });*/
 
     ///add(grid);
         JPanel top = new JPanel(); 
        label = new JLabel();
        updateLabelText();
        
        JButton newGameButton = new JButton();
        newGameButton.setText("Új játék");
        newGameButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                //newGame();
            }
            
        });
        
        top.add(label);
        top.add(newGameButton);
        
        JPanel mainPanel = new JPanel();      
        mainPanel.setLayout(new GridLayout(size, size));


        for (int i = 0; i < size; ++i) {
            for (int j = 0; j < size; ++j) {
                addButton(mainPanel, i, j);
                grid[i][j].setEnabled(false);
                
               //  grid[i][j].setText(String.valueOf(i) + " " + String.valueOf(j));

   //    grid[i][j].setText(String.valueOf(model.getNumber(i, j)) );
                   grid[i][j].setText(model.getNumber(i, j)+ " (i: " + String.valueOf(i) + " j:" + String.valueOf(j) + ") " );    
                   
                   if(model.getNumber(i, j)==FieldValue.WHITEHORSE){ grid[i][j].setIcon(new ImageIcon(getClass().getResource("smallwhite.png"))); grid[i][j].setEnabled(true);}
                   if(model.getNumber(i, j)==FieldValue.WHITEHORSE){ grid[i][j].setIcon(new ImageIcon(getClass().getResource("smallwhite.png"))); grid[i][j].setEnabled(true);}
                  
                   if(model.getNumber(i, j)==FieldValue.BLACKHORSE){ grid[i][j].setIcon(new ImageIcon(getClass().getResource("rsz_2smallbalck.png")));  }
                   if(model.getNumber(i, j)==FieldValue.BLACKHORSE){ grid[i][j].setIcon(new ImageIcon(getClass().getResource("rsz_2smallbalck.png"))); }
                   
                  
            }
        }
   

      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setLocationRelativeTo(null);
      setVisible(true);
      setLayout(new BorderLayout());
     
        getContentPane().add(top, BorderLayout.NORTH);
        add(mainPanel, BorderLayout.CENTER);
   }
   
   
   public static void main(String[] args) {
      new JButtonTextChangeTest();
   }
   
   
    private void addButton(JPanel mainPanel, final int i, final int j) {
        grid[i][j] = new JButton();
        mainPanel.add(grid[i][j]);


        grid[i][j].addMouseListener(new MouseAdapter() {

            @Override
            public void mouseClicked(MouseEvent e) {          
         
                 model.step(i,j);
                 updateGrid();
              
           //   ChooseHorse(i,j);    
           //   StepHorse(i,j);      
           //   ChoseBlackHorse(i,j);         
          //    StepBlackHorse(i,j);

          



            }

            private void updateGrid() {
                for (int i = 0; i < size; ++i) {
            for (int j = 0; j < size; ++j) {             
                
                System.out.println(model.getNumber(i, j));
          
                   
                   if(model.getNumber(i, j)==FieldValue.WHITEHORSE){ grid[i][j].setIcon(new ImageIcon(getClass().getResource("smallwhite.png"))); grid[i][j].setEnabled(true);}                 
                   if(model.getNumber(i, j)==FieldValue.WHITE){ grid[i][j].setBackground(Color.WHITE); grid[i][j].setIcon(null);  }
                   if(model.getNumber(i, j)==FieldValue.BLACKHORSE){ grid[i][j].setIcon(new ImageIcon(getClass().getResource("rsz_2smallbalck.png")));  }
                   if(model.getNumber(i, j)==FieldValue.GREEN){ grid[i][j].setBackground(Color.GREEN);   System.out.println("MOST LEFUT");    }
                   
                
                   
                  
            }
        }
            }

        });
           
       
        
         

}
     public void ChooseHorse(int i, int j) {
            System.out.println("lépés : " + i + " és: " +  j);         
// grid[9][9].setIcon(null);
/*
        
            int elsox = i+1;
             int elsoy = j+2;
            
             int masx = i+2;
             int  masiky = j + 1;
       
             int harx = i-1;
             int hary= j+2;
             
             int negyx = i+1;
             int negyy= j-2;
             
             int otx = i+2;
             int oty = j-1;

             
             
             int hatx = i-2;
             int haty = j+1;

             int hetx = i-1;
             int hety = j-2;

             
             int nyolcx = i-2;
             int nyolcy = j-1;
            
             System.out.println("1: " + elsox + elsoy);
              System.out.println( "2: " + masx + masiky);
               System.out.println("3: " + harx + hary);
                System.out.println( "4 : " + negyx + negyy);
                 System.out.println("5: " + otx + oty);
                 System.out.println("6: " + hatx + haty);
                    System.out.println("7: " + hetx + hety);
                    System.out.println("8: " + nyolcx + nyolcy);
                         

             grid[elsox][elsoy].setBackground(Color.GREEN);    
             grid[masx][masiky].setBackground(Color.GREEN);     
             grid[harx][hary].setBackground(Color.GREEN);     
             grid[negyx][negyy].setBackground(Color.GREEN);     
             grid[otx][oty].setBackground(Color.GREEN);     
             grid[hatx][haty].setBackground(Color.GREEN);     
             grid[hetx][hety].setBackground(Color.GREEN);     
             grid[nyolcx][nyolcy].setBackground(Color.GREEN);     

          System.out.println("i: " + i +  " j: " + j);
*/

if(grid[i][j].isEnabled()){       
       
          System.out.println("i: " + i +  " j: " + j);

          


  
         int firstgreen_x = i+1;
         int firstgreen_y =  j; //j+1;
       
       int secondgreen_x = i+1;
       int secondtgreen_y =  j;     
       
        int thirdgreen_x = i-1;
        int thirdgreen_y = j+1;

        int fourthgreen_x = i+1;
       int  fourthgreen_y = j-1;

      int fifthgreen_x = i;
     int  fifthhgreen_y = j-1;
       
         int sixthgreen_x = i-1;
       int  sixthgreen_y = j;
       
       int seventhgreen_x = i-1;
      int  seventhgreen_y = j-1;  
    
    int eightgreen_x = i;
    int  eighthgreen_y = j+1;    
       
                   

                      if (firstgreen_x>=0 && firstgreen_y>=0 &&  firstgreen_x<size && firstgreen_y<size){
                           model.setValue(firstgreen_x,firstgreen_y,FieldValue.GREEN);
                           model.setValue(i, j, FieldValue.WHITE);
                         
                           grid[i][j].setText("WHITE"); 
                           grid[i][j].setIcon(null);
                           grid[i][j].setBackground(Color.WHITE);
                           grid[i][j].setEnabled(false); 
                         
                           grid[firstgreen_x][firstgreen_y].setBackground(Color.GREEN);    
                           grid[firstgreen_x][firstgreen_y].setEnabled(true);

                          
                       }
                      
        //grid[i][j].setIcon(new ImageIcon(getClass().getResource("smallwhite.png")));
                           
  
           
     }
}
     
      public void StepHorse(int i, int j) {      
   

         for(int k=0;k<size;++k)  {
             for(int l=0; l<size; ++l){
                if(model.getNumber(i, j)==FieldValue.GREEN){
                    
                 grid[i][j].setIcon(new ImageIcon(getClass().getResource("smallwhite.png")));
                 
                 grid[i][j].setText("WHITEHORSE");  
                  grid[i][j].setEnabled(false); 
               
                   grid[i][j].setBackground(null);
                   model.setValue(i, j, FieldValue.WHITEHORSE);                   
             
                 }
                  
                 
                   for(int u=0;u<size;++u)  {
                        for(int v=0; v<size; ++v){ 
                   if(model.getNumber(u, v)==FieldValue.WHITEHORSE){
                       grid[u][v].setEnabled(false); 
                      
                   } 
             }
                   }
            
             }

            
         }
       
           updateLabelText();
      }
      
      
      
      
 ////////////BlackHorse
   public void ChoseBlackHorse(int i, int j) {
    
            System.out.println("lépés : " + i + " és: " +  j);         
for(int h=0;h<size;h++){
    for(int g=0;g<size;g++){
        if(model.getNumber(h, g)==FieldValue.BLACKHORSE){
           grid[h][g].setEnabled(true); 
           grid[h][g].setBackground(Color.RED);  
           grid[h][g].setContentAreaFilled(true);
        }
    }
}

        if(grid[i][j].isEnabled()){
      

  
         int firstgreen_x = i;
         int firstgreen_y =  j-1 ; //j+1;
       
       int secondgreen_x = i+1;
       int secondtgreen_y =  j;     
       
        int thirdgreen_x = i-1;
        int thirdgreen_y = j+1;

        int fourthgreen_x = i+1;
       int  fourthgreen_y = j-1;

      int fifthgreen_x = i;
     int  fifthhgreen_y = j-1;
       
         int sixthgreen_x = i-1;
       int  sixthgreen_y = j;
       
       int seventhgreen_x = i-1;
      int  seventhgreen_y = j-1;  
    
    int eightgreen_x = i;
    int  eighthgreen_y = j+1;    
       
                   

                      if (firstgreen_x>=0 && firstgreen_y>=0 &&  firstgreen_x<size && firstgreen_y<size){
                           model.setValue(firstgreen_x,firstgreen_y,FieldValue.GREEN);
                           model.setValue(i, j, FieldValue.BLACK);
                           grid[firstgreen_x][firstgreen_y].setBackground(Color.GREEN);
                                   
                         
                           grid[i][j].setText("BLACK"); 
                           grid[i][j].setIcon(null);
                           grid[i][j].setBackground(Color.BLACK);
                           grid[i][j].setEnabled(false); 
                         
                            
                           grid[firstgreen_x][firstgreen_y].setEnabled(true);

                          
                       }
                      
        //grid[i][j].setIcon(new ImageIcon(getClass().getResource("rsz_2smallbalck.png.png")));
                           
  
     
     }
}
      
      
      
             public void StepBlackHorse(int i, int j) {      
   

         for(int k=0;k<size;++k)  {
             for(int l=0; l<size; ++l){
                if(model.getNumber(i, j)==FieldValue.GREEN){
                 grid[i][j].setIcon(new ImageIcon(getClass().getResource("rsz_2smallbalck.png")));
                 
                 grid[i][j].setText("BLACKHORSE");  
                  grid[i][j].setEnabled(false); 
               
                   grid[i][j].setBackground(null);
                   model.setValue(i, j, FieldValue.BLACKHORSE);                
                   
             
                 }
                  
                 
                   for(int u=0;u<size;++u)  {
                        for(int v=0; v<size; ++v){ 
                   if(model.getNumber(u, v)==FieldValue.BLACKHORSE){
                       grid[u][v].setEnabled(false); 
                        
                   } 
             }
                   }
            
             }

            
         }
       
           updateLabelText();
      }  
      
      
      
      
      
      
      
      
      
      
      
         private void updateLabelText() {
        label.setText("Aktuális játékos: Fehér? " + isWhite);
    }
}