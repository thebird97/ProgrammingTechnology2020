package valami;

public class Model {

  
    private int size;
  
      public FieldValue[][] table;
          private FieldValue actualPlayer;

 public Model(int size) {
        this.size = size;
  actualPlayer = FieldValue.WHITEHORSE;

     table = new FieldValue[size][size];
        for (int i = 0; i < size; ++i) {
            for (int j = 0; j < size; ++j) {
                table[i][j] = FieldValue.EMPTY;
            }
        }
        
        for (int i = 0; i < size; ++i) {
            for (int j = 0; j < size; ++j) {
                if(i==0 && j ==0 ){table[i][j] = FieldValue.WHITEHORSE; }
                if(i==0 && j ==size-1 ){table[i][j] = FieldValue.WHITEHORSE; }
                
                if(i==size-1 && j ==0 ){table[i][j] = FieldValue.BLACKHORSE; }
                if(i==size-1 && j ==size-1 ){table[i][j] = FieldValue.BLACKHORSE; }
            }
        }
        
    }

    

    




    public FieldValue getNumber(int row, int column) {
        return table[row][column];
    }

    public void setValue(int row, int column,FieldValue fvalue ) {
         table[row][column] = fvalue;
    }
    
    
        public FieldValue step(int row, int column) {


        table[row][column] = actualPlayer;

        if (actualPlayer == FieldValue.WHITEHORSE) {
           table[row+1][column] = FieldValue.GREEN;
           table[row][column] = FieldValue.WHITE;
        } 
        
                if (actualPlayer == FieldValue.GREEN) {
           table[row][column] = FieldValue.WHITEHORSE;
   
        } 

        return table[row][column];
    }
    public FieldValue getActualPlayer() {
        return actualPlayer;
    }
    
    public void getModel(){
           for (int i = 0; i < size; ++i) {
            for (int j = 0; j < size; ++j) {
                System.out.println(table[i][j] + " ");
            }
        }
   
    }
}
