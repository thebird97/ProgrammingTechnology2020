package decorator;

public interface Room {
    void draw();
}
