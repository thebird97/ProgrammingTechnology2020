
package imagemanipulator.contract;


public interface ImageManipulatorUI {
    public void run();
}
