package forgalmidug�;

public class ForgalmiDug� {

    public static void main(String[] args) {
        new Szem�lyg�pkocsi("gk1", 12.0, 73.4).start();
        new Szem�lyg�pkocsi("gk2", 12.0, 120.9).start();
        new Kisbusz("kb1", 120.0, 730.4).start();
        new Kisbusz("kb2", 120.0, 1200.923).start();
    }
    
}
