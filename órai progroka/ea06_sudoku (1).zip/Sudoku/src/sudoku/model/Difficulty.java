package sudoku.model;

public enum Difficulty {
    EASY, MEDIUM, HARD
}
