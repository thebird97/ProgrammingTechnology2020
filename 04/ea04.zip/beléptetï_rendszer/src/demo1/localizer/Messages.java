package demo1.localizer;

public class Messages {

    public static final String FILE_NOT_FOUND = "file.notfound";
    public static final String INVALID_FILE_FORMAT = "file.format";
    public static final String INVALID_LINES = "file.invalid_lines";
}
